import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final cellNoController = TextEditingController();
  final shiftController = TextEditingController();
  final degreeController = TextEditingController();

  String message = "";
  bool isLoading = false;

  Future<void> registerUser() async {
    setState(() {
      isLoading = true;
      message = "⏳ Registering, please wait...";
    });

    final url = Uri.parse("https://devtechtop.com/store/public/insert_user");

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name": nameController.text.trim(),
          "email": emailController.text.trim(),
          "password": passwordController.text.trim(),
          "cell_no": cellNoController.text.trim(),
          "shift": shiftController.text.trim(),
          "degree": degreeController.text.trim(),
        }),
      );

      final data = jsonDecode(response.body);
      print("Response: ${response.body}"); // For debugging

      if (response.statusCode == 200 &&
          (data['status'] == 'success' || data['success'] == true)) {
        setState(() {
          message = "✅ Registration successful! Redirecting to login...";
        });

        Future.delayed(const Duration(seconds: 2), () {
          Navigator.pushReplacementNamed(context, '/login');
        });
      } else {
        setState(() {
          message = "❌ ${data['message'] ?? 'Registration failed. Try again.'}";
        });
      }
    } catch (e) {
      print("Error: $e");
      setState(() {
        message = "❌ An error occurred. Please try again.";
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Widget _buildTextField(
      TextEditingController controller,
      String label,
      IconData icon, {
        bool obscureText = false,
        TextInputType keyboardType = TextInputType.text,
      }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.deepPurple),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade50,
      appBar: AppBar(
        title: const Text("📝 sign_up"),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: ListView(
          children: [
            _buildTextField(nameController, "Name", Icons.person),
            const SizedBox(height: 15),
            _buildTextField(emailController, "Email", Icons.email,
                keyboardType: TextInputType.emailAddress),
            const SizedBox(height: 15),
            _buildTextField(passwordController, "Password", Icons.lock,
                obscureText: true),
            const SizedBox(height: 15),
            _buildTextField(cellNoController, "Cell No", Icons.phone,
                keyboardType: TextInputType.phone),
            const SizedBox(height: 15),
            _buildTextField(shiftController, "Shift", Icons.schedule),
            const SizedBox(height: 15),
            _buildTextField(degreeController, "Degree", Icons.school),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: isLoading ? null : registerUser,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                minimumSize: const Size.fromHeight(55),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                elevation: 8,
              ),
              child: isLoading
                  ? const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              )
                  : const Text(
                "Register",
                style:
                TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: message.contains("✅")
                      ? Colors.green.shade700
                      : Colors.red.shade700,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
