import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  final String loggedInUserId;

  const HomePage({super.key, required this.loggedInUserId});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController userIdController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  List<dynamic> users = [];
  List<dynamic> allRequests = [];
  String errorMessage = '';
  String requestMessage = '';

  @override
  void initState() {
    super.initState();
    userIdController.text = widget.loggedInUserId;
  }

  Future<void> fetchUsers() async {
    final url = Uri.parse("https://devtechtop.com/store/public/api/all_user");

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "user_id": userIdController.text.trim(),
      }),
    );

    final responseData = jsonDecode(response.body);

    setState(() {
      if (response.statusCode == 200 && responseData['status'] == "success") {
        users = responseData['data'];
        errorMessage = '';
      } else {
        users = [];
        errorMessage = responseData.toString();
      }
    });
  }

  Future<void> sendScholarRequest(String receiverId) async {
    final url = Uri.parse("https://devtechtop.com/store/public/api/scholar_request/insert");

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "sender_id": userIdController.text.trim(),
        "receiver_id": receiverId,
        "description": descriptionController.text.trim(),
      }),
    );

    final responseData = jsonDecode(response.body);

    setState(() {
      if (response.statusCode == 200 && responseData['status'] == "success") {
        requestMessage = "✅ Request sent successfully!";
      } else {
        requestMessage = "❌ Error: ${responseData['errors'] ?? responseData}";
      }
    });
  }

  Future<void> fetchAllRequests() async {
    final userId = userIdController.text.trim();
    if (userId.isEmpty) return;

    final url = Uri.parse("https://devtechtop.com/store/public/api/scholar_request/all");

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_id": userId}),
    );

    final responseData = jsonDecode(response.body);

    if (response.statusCode == 200 && responseData['status'] == 'success') {
      final List<dynamic> requests = responseData['data'];

      if (users.isEmpty) await fetchUsers();

      setState(() {
        allRequests = requests.map((req) {
          final sender = users.firstWhere(
                (u) => u['id'].toString() == req['sender_id'].toString(),
            orElse: () => {'name': 'Unknown'},
          );
          final receiver = users.firstWhere(
                (u) => u['id'].toString() == req['receiver_id'].toString(),
            orElse: () => {'name': 'Unknown'},
          );
          return {
            ...req,
            'sender_name': sender['name'],
            'receiver_name': receiver['name'],
          };
        }).toList();
      });
    } else {
      setState(() {
        allRequests = [];
      });
    }
  }

  void showRequestsDialog() async {
    await fetchAllRequests();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("All Scholar Requests"),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: allRequests.length,
            itemBuilder: (context, index) {
              final req = allRequests[index];
              final isSent = req['sender_id'] == userIdController.text.trim();
              return ListTile(
                leading: Icon(isSent ? Icons.send : Icons.inbox, color: isSent ? Colors.teal : Colors.deepOrange),
                title: Text(req['description'] ?? "No Description"),
                subtitle: Text(
                  isSent
                      ? "To: ${req['receiver_name']} (User ID: ${req['receiver_id']})"
                      : "From: ${req['sender_name']} (User ID: ${req['sender_id']})",
                  style: TextStyle(fontStyle: FontStyle.italic),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.deepPurple),
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Colors.deepPurpleAccent;
    final accentColor = Colors.amber.shade600;

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 6,
        title: Row(
          children: [
            Icon(Icons.people, color: accentColor),
            SizedBox(width: 8),
            Text(
              'User Data Viewer',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.white,
                letterSpacing: 1.1,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          children: [
            TextField(
              controller: userIdController,
              decoration: InputDecoration(
                labelText: 'Your User ID',
                labelStyle: TextStyle(color: primaryColor),
                prefixIcon: Icon(Icons.person_outline, color: primaryColor),
                filled: true,
                fillColor: Colors.white,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: primaryColor.withOpacity(0.5), width: 1.8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: primaryColor, width: 2.5),
                ),
              ),
              style: TextStyle(color: primaryColor.darken(0.1)),
            ),
            SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: fetchUsers,
                    icon: Icon(Icons.download, color: Colors.white),
                    label: Text('Fetch Users'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      padding: EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ),
                SizedBox(width: 20),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: showRequestsDialog,
                    icon: Icon(Icons.list_alt, color: Colors.white),
                    label: Text('View Requests'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentColor,
                      padding: EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ),
              ],
            ),
            if (errorMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 18),
                child: Text(errorMessage, style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
              ),
            if (requestMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(requestMessage, style: TextStyle(color: Colors.teal, fontWeight: FontWeight.w600)),
              ),
            SizedBox(height: 14),
            Expanded(
              child: users.isEmpty
                  ? Center(
                child: Text(
                  'No users to display.\nTap "Fetch Users" to load.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                ),
              )
                  : ListView.builder(
                itemCount: users.length,
                itemBuilder: (context, index) {
                  final user = users[index];
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 4,
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                      title: Text(
                        user['name'] ?? 'No Name',
                        style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor.darken(0.2)),
                      ),
                      subtitle: Text(
                        user['email'] ?? 'No Email',
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                      trailing: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accentColor,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                        ),
                        onPressed: () {
                          descriptionController.clear();
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text('Send Scholar Request', style: TextStyle(color: primaryColor)),
                              content: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text("To: ${user['name']}", style: TextStyle(fontWeight: FontWeight.w600)),
                                  SizedBox(height: 12),
                                  TextField(
                                    controller: descriptionController,
                                    decoration: InputDecoration(
                                      hintText: "Enter description",
                                      filled: true,
                                      fillColor: Colors.grey.shade100,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(14),
                                        borderSide: BorderSide(color: primaryColor, width: 2.5),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              actions: [
                                TextButton(
                                  style: TextButton.styleFrom(foregroundColor: primaryColor),
                                  onPressed: () => Navigator.of(context).pop(),
                                  child: Text("Cancel"),
                                ),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: accentColor,
                                  ),
                                  onPressed: () {
                                    sendScholarRequest(user['id'].toString());
                                    Navigator.of(context).pop();
                                  },
                                  child: Text("Send"),
                                ),
                              ],
                            ),
                          );
                        },
                        child: Text("Request", style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Extension to darken a color slightly
extension ColorUtils on Color {
  Color darken([double amount = .1]) {
    assert(amount >= 0 && amount <= 1);
    final hsl = HSLColor.fromColor(this);
    final hslDark = hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0));
    return hslDark.toColor();
  }
}
