package com.example.view_request

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
