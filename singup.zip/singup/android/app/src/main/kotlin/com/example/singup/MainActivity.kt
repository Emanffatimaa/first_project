package com.example.singup

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
