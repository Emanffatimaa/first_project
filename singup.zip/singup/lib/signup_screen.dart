import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cellNoController = TextEditingController();
  TextEditingController shiftController = TextEditingController();
  TextEditingController degreeController = TextEditingController();

  Future<void> signup() async {
    var url = Uri.parse('https://devtechtop.com/store/public/insert_user');
    var response = await http.post(
      url,
      body: {
        'name': nameController.text,
        'email': emailController.text,
        'password': passwordController.text,
        'cell_no': cellNoController.text,
        'shift': shiftController.text,
        'degree': degreeController.text,
      },
    );

    var responseData = json.decode(response.body);
    if (responseData['status'] == 'error') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Signup failed: ${responseData['errors']}')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Signup Successful!')),
      );
      Navigator.pushNamed(context, '/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Signup')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: nameController, decoration: InputDecoration(labelText: 'Name')),
              TextFormField(controller: emailController, decoration: InputDecoration(labelText: 'Email')),
              TextFormField(controller: passwordController, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
              TextFormField(controller: cellNoController, decoration: InputDecoration(labelText: 'Cell No')),
              TextFormField(controller: shiftController, decoration: InputDecoration(labelText: 'Shift')),
              TextFormField(controller: degreeController, decoration: InputDecoration(labelText: 'Degree')),
              ElevatedButton(onPressed: signup, child: Text('Signup')),
            ],
          ),
        ),
      ),
    );
  }
}
