import 'package:flutter/material.dart';
import 'signup_screen.dart';
import 'login_screen.dart';
import 'user_list_screen.dart';
import 'friend_request_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter API Project',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => SignupScreen(),
        '/login': (context) => LoginScreen(),
        '/userList': (context) => UserListScreen(),
        '/friendRequest': (context) => FriendRequestScreen(),
      },
    );
  }
}
