import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class FriendRequestScreen extends StatefulWidget {
  @override
  _FriendRequestScreenState createState() => _FriendRequestScreenState();
}

class _FriendRequestScreenState extends State<FriendRequestScreen> {
  TextEditingController userIdController = TextEditingController();
  TextEditingController requestToController = TextEditingController();

  Future<void> sendRequest() async {
    var url = Uri.parse('https://devtechtop.com/store/public/api/scholar_request/insert');
    var response = await http.post(
      url,
      body: {
        'USER_ID': userIdController.text,
        'request_to': requestToController.text,
      },
    );

    var responseData = json.decode(response.body);
    if (responseData['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Request Sent Successfully!')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send request: ${responseData['errors']}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Send Friend Request')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(controller: userIdController, decoration: InputDecoration(labelText: 'Your User ID')),
            TextFormField(controller: requestToController, decoration: InputDecoration(labelText: 'Request To (User ID)')),
            ElevatedButton(onPressed: sendRequest, child: Text('Send Request')),
          ],
        ),
      ),
    );
  }
}
