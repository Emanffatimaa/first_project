import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String insertUrl = "http://grade.fatimatehreem.com/create_api/api/insert";
  static const String selectUrl = "http://grade.fatimatehreem.com/create_api/api/select";

  Future<bool> insertStudent(String id, String name, String department) async {
    final response = await http.post(
      Uri.parse(insertUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "student_id": id,
        "student_name": name,
        "student_department": department,
      }),
    );

    return response.statusCode == 200;
  }

  Future<List<Map<String, dynamic>>> fetchStudents() async {
    final response = await http.get(Uri.parse(selectUrl));

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      return List<Map<String, dynamic>>.from(data);
    } else {
      return [];
    }
  }
}

