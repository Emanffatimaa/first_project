package com.example.picture_browsing

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
