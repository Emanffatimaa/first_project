import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  static const String insertUrl = "http://grade.fatimatehreem.com/create_api/api/insert";
  static const String selectUrl = "http://grade.fatimatehreem.com/create_api/api/select";

  // Insert student with picture upload
  Future<bool> insertStudent(String id, String name, String department, File? image) async {
    var request = http.MultipartRequest("POST", Uri.parse(insertUrl));

    request.fields["student_id"] = id;
    request.fields["student_name"] = name;
    request.fields["student_department"] = department;

    if (image != null) {
      request.files.add(await http.MultipartFile.fromPath('picture', image.path));
    }

    var response = await request.send();
    return response.statusCode == 201;
  }

  // Fetch students including picture
  Future<List<Map<String, dynamic>>> fetchStudents() async {
    final response = await http.get(Uri.parse(selectUrl));

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(await response.body);

      return List<Map<String, dynamic>>.from(data.map((student) {
        return {
          "student_id": student["student_id"],
          "student_name": student["student_name"],
          "student_department": student["student_department"],
          "picture": student["picture"] != null
              ? "http://grade.fatimatehreem.com/" + student["picture"] // Correct URL Format
              : null
        };
      }));
    } else {
      return [];
    }
  }
}
