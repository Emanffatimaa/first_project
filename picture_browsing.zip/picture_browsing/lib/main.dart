import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'api_service.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ApiService apiService = ApiService();
  List<Map<String, dynamic>> students = [];
  bool isLoading = false;

  final TextEditingController idController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController departmentController = TextEditingController();

  File? _image;

  // Image Picker Function
  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _addStudent() async {
    bool success = await apiService.insertStudent(
      idController.text,
      nameController.text,
      departmentController.text,
      _image, // Image file
    );
    if (success) {
      _fetchStudents();
    }
  }

  void _fetchStudents() async {
    setState(() {
      isLoading = true;
    });

    List<Map<String, dynamic>> data = await apiService.fetchStudents();

    setState(() {
      students = data;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.lightBlue),
      home: Scaffold(
        appBar: AppBar(title: const Text("Student API App")),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(controller: idController, decoration: const InputDecoration(labelText: "Student ID")),
              TextField(controller: nameController, decoration: const InputDecoration(labelText: "Student Name")),
              TextField(controller: departmentController, decoration: const InputDecoration(labelText: "Department")),
              const SizedBox(height: 10),
              // Image Picker Button
              ElevatedButton(
                onPressed: _pickImage,
                child: const Text("Select Picture"),
              ),
              if (_image != null) Image.file(_image!, height: 100), // Preview Image
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _addStudent,
                child: const Text("Insert Student"),
              ),
              ElevatedButton(
                onPressed: _fetchStudents,
                child: const Text("Fetch Students"),
              ),
              isLoading
                  ? const CircularProgressIndicator()
                  : Expanded(
                child: ListView.builder(
                  itemCount: students.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        title: Text(students[index]["student_name"]),
                        subtitle: Text(students[index]["student_department"]),
                        leading: students[index]["picture"] != null
                            ? Image.network(
                          students[index]["picture"], // Corrected Image URL
                          width: 50,
                          errorBuilder: (context, error, stackTrace) => Icon(Icons.error), // Handle Error
                        )
                            : const Icon(Icons.person),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
